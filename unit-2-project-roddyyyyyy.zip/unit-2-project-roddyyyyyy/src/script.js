import React from "https://esm.sh/react@19";
import ReactDOM from "https://esm.sh/react-dom@19/client";


function App() {
  return (
        <div className= "app">
      <h1 className= "title" >Trivia!</h1>
    </div>
  );
}

//This code below will allow the App Component to render(show up on the webview)!
/*const root = ReactDOM.createRoot(document.querySelector("#root"));
root.render(<App />);
*/